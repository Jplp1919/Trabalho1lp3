package trabalho01;

import java.awt.BorderLayout;
import java.awt.Font;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class Trabalho01 extends DefaultTableCellRenderer{
    static JFrame f = new JFrame("Banco de Dados");
   private static final JPanel mainPanel = new JPanel(new BorderLayout());
    public static void main(String[] args) throws SQLException {
        DataBase db = new DataBase();
        if (db.getConnection() != null) {

           Statement statement1 = null;
           ResultSet result1;
           String str = "Select * from livro";
           statement1 = db.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                   ResultSet.CONCUR_READ_ONLY);
           result1 = statement1.executeQuery("Select * from livro");
           DefaultTableModel dtm = new DefaultTableModel();
           modelWorks mw = new modelWorks();
           dtm = mw.fillModel(result1, statement1, str);
           JTable table = new JTable(dtm);
           
                   table.setFont(new Font("Serif", Font.PLAIN, 28)); //fonte do conteudo da tabela
       
        table.setRowHeight(table.getRowHeight() + 15);
        java.awt.EventQueue.invokeLater(new Runnable() {
               @Override
               public void run() {
                   f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                   f.setExtendedState(JFrame.MAXIMIZED_BOTH);
                   
                   f.setLocationRelativeTo(null);
                   //timer atualizando o progama
                   mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);
                   
               }
           });

           
           f.setVisible(true);
           
        } else{
            System.out.println("NO CONNECTION");
        }
    }
 

}
