
package trabalho01;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;


public class modelWorks  {
DefaultTableModel df = new DefaultTableModel(); 
      public DefaultTableModel fillModel(ResultSet rs, Statement stm, String str) {
     try{
         rs.first(); 
     } catch(SQLException e){
         System.out.println("SQL ERROR");
     }
         
        try {
            rs = stm.executeQuery(str);
        rs.last();
        while (rs.previous()) {
            df.addRow(
                    new Object[]{
                        rs.getString(1), //idLivro (int)
                        rs.getString(2), //NomeLivro (varchar(45))
                        rs.getString(3), //Quantidade (int)
                        rs.getString(4), //Valor (Float)
                        
                    }
            );

        }
        
        } catch (SQLException ex) {
        Logger.getLogger(Trabalho01.class.getName()).log(Level.SEVERE, null, ex);
        
        }
    return df;   
    }

}
